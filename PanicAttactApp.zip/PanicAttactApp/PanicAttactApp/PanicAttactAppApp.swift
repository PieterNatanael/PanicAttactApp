//
//  PanicAttactAppApp.swift
//  PanicAttactApp
//
//  Created by Pieter Yoshua Natanael on 13/09/23.
//

import SwiftUI

@main
struct PanicAttactAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
